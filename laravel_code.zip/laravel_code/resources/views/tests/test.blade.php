test

@foreach($values as $value)
{{$value->id}}<br>
{{$value->text}}<br>
@endforeach
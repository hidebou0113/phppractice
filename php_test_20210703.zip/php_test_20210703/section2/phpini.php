<?php

//$test = 123;

echo $test;

phpinfo();

?>
<?php

$test = 123;
$test_2 = 456;

echo $test;
var_dump($test);
exit;
echo $test_2;


?>
<?php

$test_1 = 7;
$test_2 = 3;

$test_3 = $test_1 % $test_2;


echo $test_3;


?>

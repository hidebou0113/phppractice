<?php

$commonVariable = '共通の変数です';

function commonTest(){
  echo '外部ファイルの関数です';
}


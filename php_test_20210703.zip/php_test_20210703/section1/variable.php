<?php

// 変数 動的型付

$test_1 = 123;
$test_2 = 456;

$test_3 = $test_1 . $test_2;

// 先頭は英文字かアンダーバー

//$test = 'テストです';

// 配列 オブジェクト コレクション型
var_dump($test_3);

//echo $test;

?>

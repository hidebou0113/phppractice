<?php

//定数 変わらない数・文字 
// constant 

const MAX = 'テスト';
const MAX = 'テスト2';

echo MAX;

?>

<?php

require __DIR__ . '/common/common.php';

echo $commonVariable;

echo __FILE__;

commonTest();


?>

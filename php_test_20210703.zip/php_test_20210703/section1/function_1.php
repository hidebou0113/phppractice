<?php


function test(引数1, 引数2 ){
  //処理

  return //戻り値;

}

?>